package com.example.kelompok4;


import com.example.kelompok4.model.Person;
import com.example.kelompok4.repo.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/v1")
public class PersonController {
    private final PersonRepo personRepo;

    public PersonController(PersonRepo personRepo) {
        this.personRepo = personRepo;
    }


    @Autowired
    public PersonRepo PersonRepo(PersonRepo personRepo){
        return personRepo = personRepo;
    }

    @PostMapping("/add-person")
    public Person addPerson(@RequestBody Person person){
        return personRepo.save(person);
    }

    @PostMapping("/update-person")
    public Person updatePerson(@RequestBody Person person){
        return personRepo.save(person);
    }

    @GetMapping("/get-all-person")
    public List<Person> getAllPerson() {
        return personRepo.findAll();
    }

    @GetMapping("/get-person/{id}")
    public ResponseEntity<Person> getPersonById(@PathVariable Long id) {
        Optional<Person> person = personRepo.findById(id);
        return person.map(ResponseEntity::ok).orElseGet(()-> ResponseEntity.notFound().build());
    }

}
