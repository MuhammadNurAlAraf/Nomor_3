package com.example.kelompok4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kelompok4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
